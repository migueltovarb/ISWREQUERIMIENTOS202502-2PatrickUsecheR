import pandas as pd
codigo = ''
pelicula = ''
hora = ''
precio = 0.0
listado_funciones = []
ruta_funciones = 'funciones.csv'
class Cine:
    def __init__(self, codigo, pelicula, hora, precio):
        self.codigo = codigo
        self.pelicula = pelicula
        self.hora = hora
        self.precio = precio

    def iniciar_programa(self):
        opcion = 0
        print("Bienvenido al cine MovieTime")
        print("1. Registrar una nueva pelicula")
        print("2. Mostrar peliculas disponibles")
        print("3. Vender boletos")
        print("4. Resumen de ventas del dia")
        print("5. Salir")
        opcion = int(input("Seleccione una opcion: "))
        if opcion == 1:
            self.registrar_funcion()
        elif opcion == 2:
            self.mostrar_funciones()
        elif opcion == 3:
            self.vender_boletos()
        elif opcion == 4:
            self.resumen_ventas()
        elif opcion == 5:
            print("Gracias por usar el sistema de MovieTime")
            exit()

    def registrar_funcion(self):
        global codigo, pelicula, hora, precio, listado_funciones
        codigo = input("Ingrese el codigo de la pelicula: ")
        pelicula = input("Ingrese el nombre de la pelicula: ")
        hora = input("Ingrese la hora de la funcion (HH:MM): ")
        precio = float(input("Ingrese el precio del boleto: "))
        pelicula = {
            'Codigo': codigo,
            'Pelicula': pelicula,
            'Hora': hora,
            'Precio': precio
        }
        listado_funciones.append(pelicula)
        print("Funcion registrada exitosamente")
        df = pd.DataFrame(listado_funciones)
        df.to_csv('funciones.csv', index = False)
        self.iniciar_programa()

    def mostrar_funciones(self):
        global codigo, pelicula, hora, precio
        df = pd.read_csv(ruta_funciones)
        if df.empty:
            print("No hay funciones registradas")
        else:
            print("Funciones disponibles:")
            print(df)

    def vender_boletos(self):
        global codigo, pelicula, hora, precio
        if len(listado_funciones) == 0:
            print("No hay funciones registradas")
        else:
            print("Funciones disponibles:")
            df = pd.DataFrame(listado_funciones)
            print(df)
            codigo_funcion = input("Ingrese el codigo de la funcion: ")
            cantidad_boletos = int(input("Ingrese la cantidad de boletos a vender: "))
            for funcion in listado_funciones:
                if funcion['Codigo'] == codigo_funcion:
                    total = funcion['Precio'] * cantidad_boletos
                    print(f"Total a pagar: ${total}")
                    print("El/Los boleto(s) han sido vendidos exitosamente")
 
        self.iniciar_programa()

    def resumen_ventas(self):
        global codigo, pelicula, hora, precio
        df = pd.read_csv(ruta_funciones)
        if df.empty:
            print("No hay funciones registradas")
        else:
            print("Resumen de ventas del dia:")
            print(df)

    

iniciar_programa = Cine(codigo, pelicula, hora, precio)
iniciar_programa.iniciar_programa()
